package com.example.listviewicon.model

class kodeicon {
    var nama: String = ""
    var detail: String = ""
    var logo: Int = 0
}